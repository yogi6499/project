import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { CustomerService } from 'src/app/services/customer.service';
import {MatDialog,MatDialogConfig} from '@angular/material/dialog';
import { AddCusComponent } from '../add-cus/add-cus.component';
import { customer } from 'src/app/Models/customer';
import { OrderService } from 'src/app/services/order.service';
@Component({
  selector: 'app-show-cus',
  templateUrl: './show-cus.component.html',
  styleUrls: ['./show-cus.component.css']
})
export class ShowCusComponent implements OnInit {
  // value:string='';
  addCusScreen:Boolean=false;
  showOrderScreen:Boolean=false;
  constructor(public service:CustomerService,private dialog:MatDialog,public orderService:OrderService) { }
  listData:MatTableDataSource<any>;
  displayedColumns:string[]=['CustomerNumber','Name','ContactNumber','Address','EmailId','Options']
  ngOnInit() {
    //this.refreshCusList();
    this.service.getCusList();
  }
  // applyFilter(value:string){
  //   this.listData.filter=value.trim().toLocaleLowerCase();
  // }
  // refreshCusList(){
  //   this.service.getCusList().subscribe(data=>{this.listData=new MatTableDataSource(data);});
  // }

  onAdd(){
    const dialogConfig=new MatDialogConfig();
    dialogConfig.disableClose=true;
    dialogConfig.autoFocus=true;
    dialogConfig.width="70%";
    this.dialog.open(AddCusComponent,dialogConfig);
  }

  populateForm(selectedRecord:customer){
    this.service.formData=Object.assign({},selectedRecord);
  }

  onDelete(id:number){
    if(confirm('Are you sure to delete?')){
      this.service.deleteCus(id).subscribe(
        res=>{
          this.service.getCusList();
        }
      )
    }
  }

  getOrder(id:number){
    this.orderService.getCusOrderList(id);
  }
}
