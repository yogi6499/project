import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DelCusComponent } from './del-cus.component';

describe('DelCusComponent', () => {
  let component: DelCusComponent;
  let fixture: ComponentFixture<DelCusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DelCusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DelCusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
