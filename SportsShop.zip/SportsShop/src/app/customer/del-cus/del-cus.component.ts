import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-del-cus',
  templateUrl: './del-cus.component.html',
  styleUrls: ['./del-cus.component.css']
})
export class DelCusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
