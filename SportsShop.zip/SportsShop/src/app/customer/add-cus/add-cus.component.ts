import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { customer } from 'src/app/Models/customer';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-add-cus',
  templateUrl: './add-cus.component.html',
  styleUrls: ['./add-cus.component.css']
})
export class AddCusComponent implements OnInit {

  constructor(public service:CustomerService) { }

  ngOnInit(): void {
  }
  onSubmit(form:NgForm){
    if(this.service.formData.CustomerNumber==0)
      this.insertRecord(form);
    else
    if(confirm('Are you sure to Update?'))
      this.updateRecord(form);  
  }
resetForm(form:NgForm){
  form.form.reset();
  this.service.formData=new customer();
}

insertRecord(form:NgForm){
  this.service.addCus().subscribe(
    res=>{this.resetForm(form);
    this.service.getCusList();}
  );
  alert('Added Successfully');
}
updateRecord(form:NgForm){
  this.service.updateCus().subscribe(
    res=>{this.resetForm(form);
    this.service.getCusList();}
  );
}

}
