import { Component, OnInit } from '@angular/core';
import { order } from 'src/app/Models/order';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-show-order',
  templateUrl: './show-order.component.html',
  styleUrls: ['./show-order.component.css']
})
export class ShowOrderComponent implements OnInit {
  addOrderScreen:Boolean=false;
  constructor(public service:OrderService) { }
  
  ngOnInit(): void {
    this.service.getOrderList();
  }
  populateForm(selectedRecord:order){
    this.service.formData=Object.assign({},selectedRecord);
  }
  onDelete(id:number){
    if(confirm('Are you sure to delete?')){
      this.service.deleteOrder(id).subscribe(
        res=>{
          this.service.getOrderList();
        }
      )
      }
    }

}



