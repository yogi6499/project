import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/services/order.service';
import { NgForm } from '@angular/forms';
import { order } from 'src/app/Models/order';
@Component({
  selector: 'app-add-update-delete-order',
  templateUrl: './add-update-delete-order.component.html',
  styleUrls: ['./add-update-delete-order.component.css']
})
export class AddUpdateDeleteOrderComponent implements OnInit {

  constructor(public service:OrderService) { }

  ngOnInit(): void {
  }
  onSubmit(form:NgForm){
    
    
    if(this.service.formData.ordernumber==0){
      this.insertRecord(form);
    }
    else{
      if(confirm('Are you sure to Update?'))
      this.updateRecord(form);
    }  
  }
  resetForm(form:NgForm){
    form.form.reset();
    this.service.formData=new order();
  }
  
  insertRecord(form:NgForm){
    this.service.addOrder().subscribe(
      res=>{this.resetForm(form);
      this.service.getOrderList();}
    );
    alert('Added Successfully');
  }
  updateRecord(form:NgForm){
    this.service.updateOrder().subscribe(
      res=>{this.resetForm(form);
      this.service.getOrderList();}
    );
  }
}




