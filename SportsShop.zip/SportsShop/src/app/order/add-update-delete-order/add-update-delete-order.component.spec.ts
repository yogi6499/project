import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUpdateDeleteOrderComponent } from './add-update-delete-order.component';

describe('AddUpdateDeleteOrderComponent', () => {
  let component: AddUpdateDeleteOrderComponent;
  let fixture: ComponentFixture<AddUpdateDeleteOrderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddUpdateDeleteOrderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUpdateDeleteOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
