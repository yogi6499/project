export class customer{
    CustomerNumber:number=0;
    Name:string='';
    ContactNumber:bigint=0n;
    Address:string='';
    EmailId:string='';
}