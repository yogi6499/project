import { customer } from "./customer";
import { item } from "./item";

export class order{
    ordernumber:number=0;
    orderdate:Date=new Date();
    CustomerId:number=0;
    CustomerName:string='';
    DeleveryDate:Date=new Date();
    ItemId:number=0;
    ItemName:string='';
    PaymentMode:string='';
   
}