export class item{
    ItemNumber:number=0;
    Name:string='';
    Itemvalue:number=0;
    Color:string='';
    Size:number=0;
}