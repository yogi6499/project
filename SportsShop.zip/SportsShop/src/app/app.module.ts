import {  NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatTableModule} from '@angular/material/table';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { CustomerComponent } from './customer/customer.component';
import { ItemComponent } from './item/item.component';
import { OrderComponent } from './order/order.component';
import { ShowCusComponent } from './customer/show-cus/show-cus.component';

import { DelCusComponent } from './customer/del-cus/del-cus.component';
import { AddCusComponent } from './customer/add-cus/add-cus.component';
import { CustomerService } from './services/customer.service';
import { ItemService } from './services/item.service';
import { OrderService } from './services/order.service';
import { AddUpdateDeleteComponent } from './item/add-update-delete/add-update-delete.component';
import { ShowItemComponent } from './item/show-item/show-item.component';
import { ShowOrderComponent } from './order/show-order/show-order.component';
import { AddUpdateDeleteOrderComponent } from './order/add-update-delete-order/add-update-delete-order.component';
import { GetOrderComponent } from './customer/get-order/get-order.component';
//import { createComponent } from '@angular/compiler/src/core';
@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    ItemComponent,
    OrderComponent,
    ShowCusComponent,
    
    DelCusComponent,
    AddCusComponent,
    AddUpdateDeleteComponent,
    ShowItemComponent,
    ShowOrderComponent,
    AddUpdateDeleteOrderComponent,
    GetOrderComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,MatTableModule,MatIconModule,MatButtonModule,HttpClientModule,MatFormFieldModule,MatInputModule,
    MatDialogModule,FormsModule
  ],
  exports: [
    MatFormFieldModule,
    MatInputModule,
  ],
  providers: [CustomerService,ItemService,OrderService],
  bootstrap: [AppComponent],
  //entryComponents: [AddCusComponent]
})
export class AppModule { }
