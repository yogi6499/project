import { Component, OnInit } from '@angular/core';
import { item } from 'src/app/Models/item';
import { ItemService } from 'src/app/services/item.service';

@Component({
  selector: 'app-show-item',
  templateUrl: './show-item.component.html',
  styleUrls: ['./show-item.component.css']
})
export class ShowItemComponent implements OnInit {
  addItemScreen:Boolean=false;
  constructor(public service:ItemService) { }

  ngOnInit(){
    this.service.getItemList();
  }
  populateForm(selectedRecord:item){
    this.service.formData=Object.assign({},selectedRecord);
  }
  onDelete(id:number){
    if(confirm('Are you sure to delete?')){
      this.service.deleteItem(id).subscribe(
        res=>{
          this.service.getItemList();
        }
      )
    }
  }
}


  
  
  
  