import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { item } from 'src/app/Models/item';
import { ItemService } from 'src/app/services/item.service';

@Component({
  selector: 'app-add-update-delete',
  templateUrl: './add-update-delete.component.html',
  styleUrls: ['./add-update-delete.component.css']
})
export class AddUpdateDeleteComponent implements OnInit {

  constructor(public service:ItemService) { }

  ngOnInit(): void {
  }
  onSubmit(form:NgForm){
    
    
    if(this.service.formData.ItemNumber==0)
      this.insertRecord(form);
    else
    if(confirm('Are you sure to Update?'))
      this.updateRecord(form);  
  }
  resetForm(form:NgForm){
    form.form.reset();
    this.service.formData=new item();
  }
  
  insertRecord(form:NgForm){
    this.service.addItem().subscribe(
      res=>{this.resetForm(form);
      this.service.getItemList();}
    );
    alert('Added Successfully');
  }
  updateRecord(form:NgForm){
    this.service.updateItem().subscribe(
      res=>{this.resetForm(form);
      this.service.getItemList();}
    );
  }
  
}


