import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUpdateDeleteComponent } from './add-update-delete.component';

describe('AddUpdateDeleteComponent', () => {
  let component: AddUpdateDeleteComponent;
  let fixture: ComponentFixture<AddUpdateDeleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddUpdateDeleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUpdateDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
