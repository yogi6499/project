import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { order } from '../Models/order';
@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http:HttpClient) { }
  list:order[];
  formData:order=new order();
  readonly APIUrl="http://localhost:27497/api";
  getOrderList(){
    this.http.get(this.APIUrl+'/Orders').toPromise().then(res=>this.list=res as order[]);
  }
  getCusOrderList(id:number){
    this.http.get(this.APIUrl+'/Orders/GetOrders/'+id).toPromise().then(res=>this.list=res as order[]);
  }
  addOrder() {
    return this.http.post(this.APIUrl + '/Orders', this.formData);
}
updateOrder() {
    return this.http.put(this.APIUrl + '/Orders/'+this.formData.ordernumber, this.formData);
}
deleteOrder(id: number) {
    return this.http.delete(this.APIUrl + '/Orders/' + id);
}
}





  

