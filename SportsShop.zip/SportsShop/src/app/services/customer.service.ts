import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { customer } from '../Models/customer';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient) { }
  list:customer[];
  formData:customer=new customer();
  readonly APIUrl="http://localhost:27497/api";
  // getCusList():Observable<customer[]>{
  //   return this.http.get<customer[]>(this.APIUrl+'/Customers');
  // }
  getCusList(){
    this.http.get(this.APIUrl+'/Customers').toPromise().then(res=>this.list=res as customer[]);
  }
  addCus() {
    return this.http.post(this.APIUrl + '/Customers', this.formData);
}
updateCus() {
    return this.http.put(this.APIUrl + '/Customers/'+this.formData.CustomerNumber, this.formData);
}
deleteCus(id: number) {
    return this.http.delete(this.APIUrl + '/Customers/' + id);
}
}
