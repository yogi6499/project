

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { item } from '../Models/item';
@Injectable({
  providedIn: 'root'
})
export class ItemService {

  constructor(private http:HttpClient) { }
  list:item[];
  formData:item=new item();
  readonly APIUrl="http://localhost:27497/api";
  // getCusList():Observable<customer[]>{
  //   return this.http.get<customer[]>(this.APIUrl+'/Customers');
  // }
  getItemList(){
    this.http.get(this.APIUrl+'/Items').toPromise().then(res=>this.list=res as item[]);
  }
  addItem() {
    return this.http.post(this.APIUrl + '/Items', this.formData);
}
updateItem() {
    return this.http.put(this.APIUrl + '/Items/'+this.formData.ItemNumber, this.formData);
}
deleteItem(id: number) {
    return this.http.delete(this.APIUrl + '/Items/' + id);
}
}
